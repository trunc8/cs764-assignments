Honor Code
I, Parikshit Bansal, confirm that our submission has no material, in total or in parts, that is
plagiarized or copied.
All the work (documents, code) that we am submitting is our own and is prepared and written by us
alone.
None of the submission is copy in full or in parts of any submission that does not belong to and has
been prepared by us.

Roll Number 170050040
Group Number 07

Percentage contributed by each member :

170050040: 100%
170070021: 100%
170100025: 100%