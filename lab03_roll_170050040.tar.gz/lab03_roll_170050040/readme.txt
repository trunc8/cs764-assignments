I, Parikshit Bansal, confirm that my submission has no material, in total or in parts, that is
plagiarized or copied.
All the work (documents, code) that I am submitting is our own and is prepared and written by me
alone.
None of the submission is copy in full or in parts of any submission that does not belong to and has
been prepared by me.

Shanks
170050040
Group07
