For Lab 5,

I had not taken help or given help to any other group. The assignment represented our own work with no use of unfair practices.
The contribution of each member to the discussions and participation in solving the assignment was 100%.
100,100,100


For Lab 7,

The work attached represents my own efforts without the aid of any other student. No unfair means have been used the references are duly attached in the ReflectionEssay.


Name: Siddharth Saha
Roll No: 170100025
Date: Mar 31, 2021